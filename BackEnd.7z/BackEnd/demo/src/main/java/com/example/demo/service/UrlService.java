package com.example.demo.service;

import com.example.demo.domain.Book;
import com.example.demo.domain.Customer;
import com.example.demo.domain.Url;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.repository.UrlRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@AllArgsConstructor
@Service
public class UrlService {

    // Pulls from the repo to work with data

    private final UrlRepository urlRepository;
    private final CustomerRepository customerRepository;

    public Url create(Url url, String userId){

        Customer customer = customerRepository.findByUserId(userId).orElse(null);

        if(customer != null){
            url.setCustomer(customer);
        }


        return urlRepository.save(url);
    }

    public List<Url> findAll(String userId){
        Customer customer = customerRepository.findByUserId(userId).orElse(null);

        System.out.println("UrlSErvice > findAllByUserId : " + userId);

        if(customer != null){
            return urlRepository.findAllUrlsByCustomer(customer);
        }

        return null;
    }


}
