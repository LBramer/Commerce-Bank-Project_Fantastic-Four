package com.example.demo.controller;


import com.example.demo.domain.Url;
import com.example.demo.service.UrlService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@AllArgsConstructor
public class UrlController {

    // Uses the Service layers functions to alter data, receives data from the front end via
    // POST & GET mapping. POST = send, GET = receive, PUT = update

    private final UrlService urlService;

    @CrossOrigin
    @PostMapping("/urls")
    public ResponseEntity<?> save(@RequestBody Url url){

        System.out.println("URL name : " + url.getName());
        System.out.println("URL : " + url.getUrl());

        String userId = "";

        return new ResponseEntity<>(urlService.create(url, userId), HttpStatus.CREATED);
    }

    @CrossOrigin
    @GetMapping("/url")
    public ResponseEntity<?> findAllUrls(){

        String userId = "user";
        System.out.println("FindAllUrls: " + userId);
        return new ResponseEntity<>(urlService.findAll(userId), HttpStatus.OK);
    }

}
